#!/usr/bin/env bash
java.exe -jar diao.jar